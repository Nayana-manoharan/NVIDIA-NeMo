# Description.md

## ✅ Implemented Features
- FastAPI app with /transcribe endpoint.
- Audio validation for format, sample rate, and duration.
- ONNX inference using NVIDIA NeMo Hindi model.
- Dockerfile for containerization.
- README with instructions and curl sample.

## 🛠️ Issues Faced
- ONNX export requires GPU, workaround done using pre-export simulation.
- Limited real-time transcription capabilities due to inference stub.

## 🧩 Limitations
- Current transcription result is simulated, needs real decoder.
- Async inference not implemented; can be added using `asyncio`.

## 🔄 Future Improvements
- Integrate real decoding with CTC decoder.
- Add WebSocket support for real-time streaming.