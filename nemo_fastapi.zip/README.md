# 🧠 FastAPI ASR Application using NVIDIA NeMo + ONNX

## ✅ Features
- 🎤 Transcribes 5–10 sec `.wav` audio clips in Hindi
- 🧠 NeMo Conformer-CTC model optimized with ONNX
- ⚡ FastAPI backend with `/transcribe` endpoint
- ✅ Input validation for format, sample rate, duration
- 🐳 Lightweight Docker container

## 🚀 Build & Run

### Export the ONNX model
```bash
python app/model_export.py
```

### Build Docker
```bash
docker build -t nemo-asr-fastapi .
```

### Run Docker
```bash
docker run -p 8000:8000 nemo-asr-fastapi
```

## 🔍 Test API

```bash
curl -X POST http://localhost:8000/transcribe -F "file=@test_audio/sample.wav"
```