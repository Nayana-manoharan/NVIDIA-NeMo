import librosa

def validate_audio(file_path):
    signal, sr = librosa.load(file_path, sr=None)
    duration = librosa.get_duration(y=signal, sr=sr)
    if sr != 16000:
        raise ValueError("Audio must be sampled at 16kHz.")
    if not (5 <= duration <= 10):
        raise ValueError("Audio duration must be between 5 and 10 seconds.")