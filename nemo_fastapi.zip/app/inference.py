import onnxruntime
import numpy as np
import librosa

# Load the ONNX model
model_path = "app/models/stt_hi_conformer_ctc_medium.onnx"
sess = onnxruntime.InferenceSession(model_path)

def transcribe_audio(file_path):
    signal, sr = librosa.load(file_path, sr=16000)
    input_values = np.expand_dims(signal, axis=0).astype(np.float32)
    ort_inputs = {sess.get_inputs()[0].name: input_values}
    ort_outs = sess.run(None, ort_inputs)
    # Simulated transcription output
    return "Sample transcription from ONNX model."