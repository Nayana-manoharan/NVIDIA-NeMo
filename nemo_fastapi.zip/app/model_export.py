from nemo.collections.asr.models import EncDecCTCModel
import torch

def export_to_onnx():
    model = EncDecCTCModel.from_pretrained(model_name="stt_hi_conformer_ctc_medium")
    model.export(output="app/models/stt_hi_conformer_ctc_medium.onnx")

if __name__ == "__main__":
    export_to_onnx()